'use client'
import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'

const TIMES = ['10:00', '11:00', '13:00', '14:00', '15:00', '16:00', '17:00']
const DURATIONS = [30, 45, 60]

export default function BookPage() {
  const { id } = useParams()
  const router = useRouter()
  const supabase = createClient()
  const [mentor, setMentor] = useState<any>(null)
  const [selectedDate, setSelectedDate] = useState<number | null>(null)
  const [selectedTime, setSelectedTime] = useState('11:00')
  const [duration, setDuration] = useState(30)
  const [question, setQuestion] = useState('')
  const [loading, setLoading] = useState(false)

  const today = new Date()
  const year = today.getFullYear()
  const month = today.getMonth()
  const daysInMonth = new Date(year, month + 1, 0).getDate()
  const firstDay = new Date(year, month, 1).getDay()

  useEffect(() => {
    supabase.from('profiles').select('*').eq('id', id).single().then(({ data }) => setMentor(data))
  }, [id])

  async function handleBook() {
    setLoading(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user || !selectedDate) { setLoading(false); return }

    const scheduledAt = new Date(year, month, selectedDate, parseInt(selectedTime.split(':')[0]), 0)
    await supabase.from('coffeechats').insert({
      mentor_id: id,
      mentee_id: user.id,
      scheduled_at: scheduledAt.toISOString(),
      duration_minutes: duration,
      pre_question: question,
      status: 'pending',
    })
    await supabase.from('notifications').insert({
      recipient_id: id,
      message: `새로운 커피챗 신청이 도착했어요!`,
      is_read: false,
    })
    router.push('/bookings?confirmed=true')
  }

  if (!mentor) return <div className="flex items-center justify-center h-screen text-gray-400">로딩 중...</div>

  const monthNames = ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월']

  return (
    <div className="pb-10">
      <div className="px-5 pt-4 flex items-center gap-3 mb-4">
        <button onClick={() => router.back()} className="w-9 h-9 bg-gray-100 rounded-full flex items-center justify-center">←</button>
        <span className="font-bold text-gray-900">커피챗 신청</span>
      </div>

      <div className="mx-5 bg-white rounded-2xl p-4 mb-5 border border-gray-100 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center font-bold text-sm text-blue-700">
          {mentor.name?.slice(0, 1)}
        </div>
        <div>
          <p className="font-bold text-sm text-gray-900">{mentor.name}</p>
          <p className="text-xs text-gray-500">{mentor.company}</p>
        </div>
      </div>

      <div className="px-5 mb-5">
        <h3 className="font-bold text-sm text-gray-900 mb-3">{year}년 {monthNames[month]}</h3>
        <div className="grid grid-cols-7 gap-1 text-center mb-1">
          {['일', '월', '화', '수', '목', '금', '토'].map(d => (
            <div key={d} className="text-xs text-gray-400 py-1">{d}</div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1 text-center">
          {Array.from({ length: firstDay }).map((_, i) => <div key={`e${i}`} />)}
          {Array.from({ length: daysInMonth }, (_, i) => i + 1).map(d => (
            <button key={d} onClick={() => setSelectedDate(d)}
              disabled={d < today.getDate()}
              className={`aspect-square flex items-center justify-center text-sm rounded-full transition-all
                ${selectedDate === d ? 'bg-blue-700 text-white font-bold' : d < today.getDate() ? 'text-gray-200' : 'text-gray-700 hover:bg-gray-100'}`}>
              {d}
            </button>
          ))}
        </div>
      </div>

      <div className="px-5 mb-5">
        <h3 className="font-bold text-sm text-gray-900 mb-3">시간 선택</h3>
        <div className="grid grid-cols-3 gap-2">
          {TIMES.map(t => (
            <button key={t} onClick={() => setSelectedTime(t)}
              className={`py-2.5 rounded-xl text-sm font-medium transition-all border ${selectedTime === t ? 'bg-blue-700 text-white border-blue-700' : 'bg-white text-gray-700 border-gray-200'}`}>
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="px-5 mb-5">
        <h3 className="font-bold text-sm text-gray-900 mb-3">진행 시간</h3>
        <div className="flex gap-2">
          {DURATIONS.map(d => (
            <button key={d} onClick={() => setDuration(d)}
              className={`px-4 py-2 rounded-full text-sm font-semibold border transition-all ${duration === d ? 'bg-blue-50 border-blue-600 text-blue-700' : 'bg-white border-gray-200 text-gray-500'}`}>
              {d}분
            </button>
          ))}
        </div>
      </div>

      <div className="px-5 mb-5">
        <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">사전 질문 (선택)</p>
        <textarea
          className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-blue-500 resize-none"
          rows={3} placeholder="멘토에게 미리 전달할 내용을 적어주세요"
          value={question} onChange={e => setQuestion(e.target.value)}
        />
      </div>

      <div className="mx-5 bg-blue-50 rounded-2xl p-4 mb-6 border border-blue-100">
        <div className="flex justify-between text-sm mb-1.5">
          <span className="text-gray-600">커피챗 비용</span>
          <span className="font-bold text-blue-700">무료</span>
        </div>
        <div className="flex justify-between text-sm mb-3">
          <span className="text-gray-600">플랫폼 수수료</span>
          <span className="font-bold text-blue-700">무료</span>
        </div>
        <div className="border-t border-blue-100 pt-3 flex justify-between">
          <span className="font-bold text-blue-900">합계</span>
          <span className="font-black text-blue-900 text-base">0원</span>
        </div>
      </div>

      <div className="px-5">
        <button onClick={handleBook} disabled={!selectedDate || loading}
          className="w-full bg-blue-700 text-white font-bold rounded-2xl py-4 text-sm active:opacity-80 disabled:opacity-40">
          {loading ? '신청 중...' : '신청 완료'}
        </button>
      </div>
    </div>
  )
}
