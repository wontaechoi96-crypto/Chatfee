'use client'
import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'

export default function ProfilePage() {
  const { id } = useParams()
  const router = useRouter()
  const supabase = createClient()
  const [mentor, setMentor] = useState<any>(null)
  const [myProfile, setMyProfile] = useState<any>(null)
  const [reviews, setReviews] = useState<any[]>([])

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const { data } = await supabase.from('profiles').select('*').eq('id', user.id).single()
        setMyProfile(data)
      }
      const { data: m } = await supabase.from('profiles').select('*').eq('id', id).single()
      setMentor(m)
      const { data: r } = await supabase.from('reviews').select('*, reviewer:reviewer_id(name)').eq('reviewee_id', id).limit(5)
      setReviews(r || [])
    }
    load()
  }, [id])

  if (!mentor) return <div className="flex items-center justify-center h-screen text-gray-400">로딩 중...</div>

  const isAlumni = myProfile?.school === mentor.school && myProfile?.major === mentor.major
  const colors = ['bg-blue-100 text-blue-700', 'bg-green-100 text-green-700', 'bg-red-100 text-red-700', 'bg-purple-100 text-purple-700']
  const color = colors[mentor.name?.charCodeAt(0) % colors.length] || colors[0]

  return (
    <div className="pb-24">
      <div className="px-5 pt-4 flex items-center gap-3">
        <button onClick={() => router.back()} className="w-9 h-9 bg-gray-100 rounded-full flex items-center justify-center text-base">←</button>
        <span className="font-bold text-gray-900">멘토 프로필</span>
      </div>

      <div className="text-center px-5 mt-6 mb-6">
        <div className={`w-20 h-20 rounded-full flex items-center justify-center font-bold text-2xl mx-auto mb-3 ${color}`}>
          {mentor.name?.slice(0, 1)}
        </div>
        <h2 className="text-xl font-black text-gray-900">{mentor.name}</h2>
        <p className="text-sm text-gray-500 mt-1">{mentor.company} · {mentor.position || '재직중'}</p>
        {isAlumni && <span className="inline-block mt-2 text-xs font-bold bg-amber-50 text-amber-700 px-3 py-1 rounded-md">★ {mentor.school} {mentor.major} 직속선배</span>}
      </div>

      <div className="flex gap-2.5 px-5 mb-5">
        {[
          { label: '커피챗', value: reviews.length || 0, color: 'text-blue-700' },
          { label: '평점', value: '4.8', color: 'text-amber-500' },
          { label: '경력', value: '5년+', color: 'text-green-600' },
        ].map(s => (
          <div key={s.label} className="flex-1 bg-white rounded-2xl p-3 text-center border border-gray-100">
            <p className={`text-lg font-black ${s.color}`}>{s.value}</p>
            <p className="text-xs text-gray-400 mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {mentor.mentor_intro && (
        <div className="mx-5 bg-white rounded-2xl p-4 mb-3 border border-gray-100">
          <p className="text-xs font-bold text-gray-700 mb-2">소개</p>
          <p className="text-sm text-gray-600 leading-relaxed">{mentor.mentor_intro}</p>
        </div>
      )}

      <div className="mx-5 bg-white rounded-2xl p-4 mb-3 border border-gray-100">
        <p className="text-xs font-bold text-gray-700 mb-3">학력 / 경력</p>
        {mentor.company && (
          <div className="flex gap-2.5 items-center mb-2">
            <div className="w-2 h-2 rounded-full bg-blue-600 flex-shrink-0"></div>
            <p className="text-sm text-gray-700">{mentor.company} · {mentor.department || ''} {mentor.position || ''}</p>
          </div>
        )}
        {mentor.school && (
          <div className="flex gap-2.5 items-center">
            <div className="w-2 h-2 rounded-full bg-blue-200 flex-shrink-0"></div>
            <p className="text-sm text-gray-700">{mentor.school} {mentor.major}</p>
          </div>
        )}
      </div>

      {reviews.length > 0 && (
        <div className="mx-5 bg-white rounded-2xl p-4 mb-5 border border-gray-100">
          <p className="text-xs font-bold text-gray-700 mb-3">후기</p>
          {reviews.map(r => (
            <div key={r.id} className="mb-2">
              <span className="text-yellow-400 text-xs">{'★'.repeat(r.rating)}</span>
              <p className="text-sm text-gray-600 mt-0.5">"{r.comment}"</p>
            </div>
          ))}
        </div>
      )}

      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] px-5 pb-6 pt-3 bg-gradient-to-t from-[#F8F7F4] to-transparent">
        <button onClick={() => router.push(`/book/${mentor.id}`)}
          className="w-full bg-blue-700 text-white font-bold rounded-2xl py-4 text-sm active:opacity-80">
          커피챗 신청하기 → 무료
        </button>
      </div>
    </div>
  )
}
