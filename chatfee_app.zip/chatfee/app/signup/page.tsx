'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'
import Link from 'next/link'

export default function SignupPage() {
  const router = useRouter()
  const supabase = createClient()
  const [role, setRole] = useState<'mentee' | 'mentor' | 'both'>('mentee')
  const [form, setForm] = useState({ name: '', email: '', password: '', school: '', major: '', company: '' })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const set = (k: string) => (e: any) => setForm(f => ({ ...f, [k]: e.target.value }))

  async function handleSignup() {
    if (!form.name || !form.email || !form.password) { setError('이름, 이메일, 비밀번호는 필수예요.'); return }
    setLoading(true); setError('')
    const { data, error: signUpError } = await supabase.auth.signUp({ email: form.email, password: form.password })
    if (signUpError) { setError(signUpError.message); setLoading(false); return }
    if (data.user) {
      await supabase.from('profiles').insert({
        id: data.user.id,
        name: form.name,
        school: form.school,
        major: form.major,
        company: form.company,
        is_mentor: role === 'mentor' || role === 'both',
      })
    }
    router.push('/home')
  }

  const roles = [
    { key: 'mentee', label: '멘티 (조언 받기)' },
    { key: 'mentor', label: '멘토 (조언 해주기)' },
    { key: 'both', label: '둘 다' },
  ]

  return (
    <div className="flex flex-col min-h-screen px-7 py-10">
      <Link href="/" className="w-9 h-9 bg-gray-100 rounded-full flex items-center justify-center text-lg mb-6">←</Link>
      <h2 className="text-xl font-bold text-gray-900 mb-1">회원가입</h2>
      <p className="text-sm text-gray-500 mb-6">역할을 선택하고 프로필을 입력해주세요</p>

      <div className="flex gap-2 mb-6 flex-wrap">
        {roles.map(r => (
          <button key={r.key} onClick={() => setRole(r.key as any)}
            className={`px-4 py-2 rounded-full text-sm font-semibold border transition-all ${role === r.key ? 'bg-blue-50 border-blue-600 text-blue-700' : 'bg-white border-gray-200 text-gray-500'}`}>
            {r.label}
          </button>
        ))}
      </div>

      <div className="flex flex-col gap-3 mb-6">
        {[
          { key: 'name', label: '이름', placeholder: '홍길동', type: 'text' },
          { key: 'email', label: '이메일', placeholder: 'email@example.com', type: 'email' },
          { key: 'password', label: '비밀번호', placeholder: '8자 이상', type: 'password' },
          { key: 'school', label: '학교', placeholder: '연세대학교', type: 'text' },
          { key: 'major', label: '전공', placeholder: '경영학과', type: 'text' },
          { key: 'company', label: '현 직장 / 관심 직종', placeholder: '맥킨지 / 컨설팅', type: 'text' },
        ].map(f => (
          <div key={f.key}>
            <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">{f.label}</p>
            <input
              className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3.5 text-sm outline-none focus:border-blue-500 transition-colors"
              type={f.type} placeholder={f.placeholder}
              value={(form as any)[f.key]} onChange={set(f.key)}
            />
          </div>
        ))}
      </div>

      {error && <p className="text-red-500 text-sm mb-3">{error}</p>}

      <button
        onClick={handleSignup} disabled={loading}
        className="w-full bg-blue-700 text-white font-semibold rounded-2xl py-4 text-sm active:opacity-80 disabled:opacity-50"
      >
        {loading ? '가입 중...' : '가입 완료'}
      </button>
    </div>
  )
}
