'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'
import BottomNav from '@/components/BottomNav'

export default function MyProfilePage() {
  const router = useRouter()
  const supabase = createClient()
  const [profile, setProfile] = useState<any>(null)
  const [editing, setEditing] = useState(false)
  const [form, setForm] = useState<any>({})
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push('/'); return }
      const { data } = await supabase.from('profiles').select('*').eq('id', user.id).single()
      setProfile(data); setForm(data || {})
    }
    load()
  }, [])

  async function handleSave() {
    setSaving(true)
    await supabase.from('profiles').update(form).eq('id', profile.id)
    setProfile({ ...profile, ...form })
    setEditing(false); setSaving(false)
  }

  async function handleLogout() {
    await supabase.auth.signOut()
    router.push('/')
  }

  const set = (k: string) => (e: any) => setForm((f: any) => ({ ...f, [k]: e.target.value }))
  const color = 'bg-blue-100 text-blue-700'

  const menuItems = [
    { label: '나의 예약', action: () => router.push('/bookings'), icon: '📅' },
    { label: editing ? '저장하기' : '프로필 편집', action: editing ? handleSave : () => setEditing(true), icon: '✏️' },
    { label: profile?.is_mentor ? '멘토 설정 편집' : '멘토로 등록하기', action: () => setEditing(true), icon: '☕', badge: !profile?.is_mentor },
    { label: '알림 설정', action: () => {}, icon: '🔔' },
  ]

  if (!profile) return <div className="flex items-center justify-center h-screen text-gray-400">로딩 중...</div>

  return (
    <div className="pb-20">
      <div className="px-5 pt-4 pb-3">
        <h1 className="text-xl font-bold text-gray-900">내 정보</h1>
      </div>

      <div className="text-center px-5 mb-6">
        <div className={`w-16 h-16 rounded-full flex items-center justify-center font-bold text-xl mx-auto mb-3 ${color}`}>
          {profile.name?.slice(0, 1) || '?'}
        </div>
        <h2 className="text-lg font-black text-gray-900">{profile.name}</h2>
        <p className="text-sm text-gray-500">{profile.company}</p>
        <p className="text-sm text-gray-400">{profile.school} {profile.major}</p>
        {profile.is_mentor && <span className="inline-block mt-2 text-xs font-bold bg-amber-50 text-amber-700 px-3 py-1 rounded-full">멘토 활동 중 ☕</span>}
      </div>

      {editing && (
        <div className="mx-5 bg-white rounded-2xl p-4 border border-gray-100 mb-4">
          <p className="text-xs font-bold text-gray-700 mb-3">프로필 편집</p>
          {[
            { key: 'name', label: '이름', type: 'text' },
            { key: 'school', label: '학교', type: 'text' },
            { key: 'major', label: '전공', type: 'text' },
            { key: 'company', label: '직장', type: 'text' },
            { key: 'position', label: '직급', type: 'text' },
            { key: 'bio', label: '한 줄 소개', type: 'text' },
            { key: 'mentor_intro', label: '멘토 소개글', type: 'textarea' },
          ].map(f => (
            <div key={f.key} className="mb-3">
              <p className="text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{f.label}</p>
              {f.type === 'textarea' ? (
                <textarea className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-blue-500 resize-none" rows={3} value={form[f.key] || ''} onChange={set(f.key)} />
              ) : (
                <input className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-blue-500" type={f.type} value={form[f.key] || ''} onChange={set(f.key)} />
              )}
            </div>
          ))}
          <div className="flex items-center gap-2 mb-1">
            <input type="checkbox" id="isMentor" checked={form.is_mentor || false} onChange={e => setForm((f: any) => ({ ...f, is_mentor: e.target.checked }))} />
            <label htmlFor="isMentor" className="text-sm text-gray-700 font-medium">멘토로 활동하기</label>
          </div>
          <div className="flex gap-2 mt-4">
            <button onClick={() => setEditing(false)} className="flex-1 border border-gray-200 text-gray-600 font-semibold rounded-xl py-2.5 text-sm">취소</button>
            <button onClick={handleSave} disabled={saving} className="flex-1 bg-blue-700 text-white font-semibold rounded-xl py-2.5 text-sm disabled:opacity-50">
              {saving ? '저장 중...' : '저장'}
            </button>
          </div>
        </div>
      )}

      <div className="px-5 flex flex-col gap-2">
        {menuItems.map(item => (
          <button key={item.label} onClick={item.action}
            className="bg-white rounded-2xl p-4 border border-gray-100 flex justify-between items-center w-full active:opacity-70">
            <span className="text-sm font-semibold text-gray-900 flex items-center gap-2">
              <span>{item.icon}</span>{item.label}
            </span>
            <div className="flex items-center gap-2">
              {item.badge && <span className="text-xs font-bold bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full">NEW</span>}
              <span className="text-gray-300">→</span>
            </div>
          </button>
        ))}
        <button onClick={handleLogout}
          className="bg-white rounded-2xl p-4 border border-gray-100 flex justify-between items-center w-full active:opacity-70 mt-2">
          <span className="text-sm font-semibold text-red-500">🚪 로그아웃</span>
          <span className="text-red-300">→</span>
        </button>
      </div>
      <BottomNav />
    </div>
  )
}
