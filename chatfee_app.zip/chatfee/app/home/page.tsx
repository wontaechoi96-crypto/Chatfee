'use client'
import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'
import BottomNav from '@/components/BottomNav'
import MentorCard from '@/components/MentorCard'

export default function HomePage() {
  const router = useRouter()
  const supabase = createClient()
  const [user, setUser] = useState<any>(null)
  const [profile, setProfile] = useState<any>(null)
  const [mentors, setMentors] = useState<any[]>([])
  const [alumni, setAlumni] = useState<any[]>([])

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) { router.push('/'); return }
      setUser(user)
      const { data: prof } = await supabase.from('profiles').select('*').eq('id', user.id).single()
      setProfile(prof)
      const { data: mentorList } = await supabase.from('profiles').select('*').eq('is_mentor', true).neq('id', user.id).limit(10)
      setMentors(mentorList || [])
      if (prof?.school && prof?.major) {
        const { data: alumniList } = await supabase.from('profiles').select('*')
          .eq('is_mentor', true).eq('school', prof.school).eq('major', prof.major).neq('id', user.id).limit(5)
        setAlumni(alumniList || [])
      }
    }
    load()
  }, [])

  return (
    <div className="pb-20">
      <div className="px-5 pt-4 pb-3 flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-black text-gray-900 tracking-tight">ChatFee</h1>
          <p className="text-sm text-gray-500">안녕하세요, {profile?.name || ''}님 👋</p>
        </div>
        <div className="w-9 h-9 rounded-full bg-blue-100 flex items-center justify-center font-bold text-sm text-blue-700">
          {profile?.name?.slice(0, 1) || '?'}
        </div>
      </div>

      <div className="px-5">
        {alumni.length > 0 && (
          <div className="bg-gradient-to-br from-blue-600 to-blue-500 rounded-2xl p-5 mb-5 text-white">
            <p className="text-xs font-bold uppercase tracking-wider opacity-80 mb-1">직속 선배 찾기</p>
            <p className="text-lg font-bold mb-3">{profile?.school} {profile?.major} 선배<br />{alumni.length}명이 활동 중이에요</p>
            <button onClick={() => router.push('/search?alumni=true')}
              className="bg-white text-blue-700 text-xs font-bold px-4 py-2 rounded-xl active:opacity-80">
              바로 보기 →
            </button>
          </div>
        )}

        <div className="flex gap-2 mb-4 overflow-x-auto pb-1">
          {['전체', '컨설팅', 'IT/테크', '금융', '스타트업'].map(c => (
            <button key={c} className={`px-3 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap border transition-all ${c === '전체' ? 'bg-blue-50 border-blue-600 text-blue-700' : 'bg-white border-gray-200 text-gray-500'}`}>
              {c}
            </button>
          ))}
        </div>

        <h2 className="font-bold text-gray-900 mb-3">추천 멘토</h2>
        {mentors.length === 0 && (
          <p className="text-sm text-gray-400 text-center py-10">아직 등록된 멘토가 없어요.<br />첫 멘토가 되어보세요!</p>
        )}
        {mentors.map(m => (
          <MentorCard key={m.id} mentor={m} isAlumni={alumni.some(a => a.id === m.id)} />
        ))}
      </div>
      <BottomNav />
    </div>
  )
}
