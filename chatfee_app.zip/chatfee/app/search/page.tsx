'use client'
import { useEffect, useState } from 'react'
import { useSearchParams } from 'next/navigation'
import { createClient } from '@/lib/supabase'
import BottomNav from '@/components/BottomNav'
import MentorCard from '@/components/MentorCard'

export default function SearchPage() {
  const supabase = createClient()
  const searchParams = useSearchParams()
  const [query, setQuery] = useState('')
  const [mentors, setMentors] = useState<any[]>([])
  const [myProfile, setMyProfile] = useState<any>(null)

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser()
      if (user) {
        const { data } = await supabase.from('profiles').select('*').eq('id', user.id).single()
        setMyProfile(data)
      }
      const isAlumni = searchParams.get('alumni') === 'true'
      let q = supabase.from('profiles').select('*').eq('is_mentor', true)
      if (isAlumni && data?.school) q = q.eq('school', data.school)
      const { data: list } = await q.limit(30)
      setMentors(list || [])
    }
    load()
  }, [])

  async function handleSearch(v: string) {
    setQuery(v)
    if (!v.trim()) {
      const { data } = await supabase.from('profiles').select('*').eq('is_mentor', true).limit(30)
      setMentors(data || []); return
    }
    const { data } = await supabase.from('profiles').select('*').eq('is_mentor', true)
      .or(`name.ilike.%${v}%,company.ilike.%${v}%,school.ilike.%${v}%,major.ilike.%${v}%`)
    setMentors(data || [])
  }

  return (
    <div className="pb-20">
      <div className="px-5 pt-4 pb-3">
        <h1 className="text-xl font-bold text-gray-900 mb-3">멘토 검색</h1>
        <input
          className="w-full bg-white border border-gray-200 rounded-xl px-4 py-3 text-sm outline-none focus:border-blue-500"
          placeholder="회사명, 직무, 이름으로 검색"
          value={query} onChange={e => handleSearch(e.target.value)}
        />
      </div>
      <div className="px-5">
        <p className="text-xs text-gray-400 mb-3">총 {mentors.length}명의 멘토</p>
        {mentors.map(m => (
          <MentorCard key={m.id} mentor={m} isAlumni={myProfile?.school === m.school && myProfile?.major === m.major} />
        ))}
        {mentors.length === 0 && (
          <p className="text-sm text-gray-400 text-center py-16">검색 결과가 없어요</p>
        )}
      </div>
      <BottomNav />
    </div>
  )
}
