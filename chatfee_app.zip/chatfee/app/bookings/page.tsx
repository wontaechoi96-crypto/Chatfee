'use client'
import { useEffect, useState } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase'
import BottomNav from '@/components/BottomNav'

export default function BookingsPage() {
  const supabase = createClient()
  const router = useRouter()
  const searchParams = useSearchParams()
  const confirmed = searchParams.get('confirmed')
  const [bookings, setBookings] = useState<any[]>([])
  const [tab, setTab] = useState<'pending' | 'confirmed' | 'completed'>('pending')
  const [showConfirm, setShowConfirm] = useState(!!confirmed)

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser()
      if (!user) return
      const { data } = await supabase.from('coffeechats')
        .select('*, mentor:mentor_id(name, company, position), mentee:mentee_id(name)')
        .or(`mentor_id.eq.${user.id},mentee_id.eq.${user.id}`)
        .order('created_at', { ascending: false })
      setBookings(data || [])
    }
    load()
  }, [])

  const filtered = bookings.filter(b => b.status === tab || (tab === 'pending' && b.status === 'pending'))

  const statusLabel: Record<string, string> = {
    pending: '확정 대기', confirmed: '확정', completed: '완료', cancelled: '취소'
  }
  const statusColor: Record<string, string> = {
    pending: 'bg-yellow-50 text-yellow-700', confirmed: 'bg-blue-50 text-blue-700',
    completed: 'bg-green-50 text-green-700', cancelled: 'bg-gray-100 text-gray-500'
  }

  return (
    <div className="pb-20">
      {showConfirm && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 px-8">
          <div className="bg-white rounded-3xl p-8 text-center w-full">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center text-3xl mx-auto mb-4">☕</div>
            <h3 className="text-lg font-black text-gray-900 mb-2">신청 완료!</h3>
            <p className="text-sm text-gray-500 mb-6">멘토가 수락하면 알림으로 알려드릴게요.</p>
            <button onClick={() => setShowConfirm(false)} className="w-full bg-blue-700 text-white font-bold rounded-2xl py-3.5 text-sm">확인</button>
          </div>
        </div>
      )}

      <div className="px-5 pt-4 pb-3">
        <h1 className="text-xl font-bold text-gray-900 mb-4">예약 현황</h1>
        <div className="flex gap-2">
          {(['pending', 'confirmed', 'completed'] as const).map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold border transition-all ${tab === t ? 'bg-blue-50 border-blue-600 text-blue-700' : 'bg-white border-gray-200 text-gray-500'}`}>
              {t === 'pending' ? '예정' : t === 'confirmed' ? '확정' : '완료'}
            </button>
          ))}
        </div>
      </div>

      <div className="px-5">
        {filtered.length === 0 && (
          <p className="text-sm text-gray-400 text-center py-16">예약 내역이 없어요</p>
        )}
        {filtered.map(b => (
          <div key={b.id} className="bg-white rounded-2xl p-4 border border-gray-100 mb-3">
            <div className="flex justify-between items-center mb-3">
              <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${statusColor[b.status]}`}>{statusLabel[b.status]}</span>
              <span className="text-xs text-gray-400">{b.scheduled_at ? new Date(b.scheduled_at).toLocaleDateString('ko', { month: 'long', day: 'numeric', weekday: 'short', hour: '2-digit', minute: '2-digit' }) : ''}</span>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center font-bold text-sm text-blue-700">
                {b.mentor?.name?.slice(0, 1)}
              </div>
              <div>
                <p className="font-bold text-sm text-gray-900">{b.mentor?.name}</p>
                <p className="text-xs text-gray-500">{b.mentor?.company} · {b.duration_minutes}분</p>
              </div>
            </div>
            {b.status === 'confirmed' && b.meeting_link && (
              <a href={b.meeting_link} target="_blank" rel="noopener noreferrer"
                className="mt-3 block text-center bg-blue-700 text-white text-xs font-bold py-2.5 rounded-xl">
                Zoom 입장하기 →
              </a>
            )}
          </div>
        ))}
      </div>
      <BottomNav />
    </div>
  )
}
